<?php

namespace App\Enum;

enum OutfitTypeEnum: string
{
    case USER_GENERATED = 'User Generated';
    case SELFIE = 'Selfie';
}
