import controller_0 from "../ux-turbo/turbo_controller.js";
import controller_1 from "../../controllers/outfit_editor_controller.js";
import controller_2 from "../../controllers/hello_controller.js";
export const eagerControllers = {"symfony--ux-turbo--turbo-core": controller_0, "outfit-editor": controller_1, "hello": controller_2};
export const lazyControllers = {};
export const isApplicationDebug = true;