// src/turbo_controller.ts
import { Controller } from "@hotwired/stimulus";
import "@hotwired/turbo";
var turbo_controller_default = class extends Controller {
};
export {
  turbo_controller_default as default
};
